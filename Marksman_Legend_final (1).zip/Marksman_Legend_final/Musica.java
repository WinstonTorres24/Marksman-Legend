import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Musica here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Musica extends Actor
{
    /**
     * Act - do whatever the Musica wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Musica()
    {
        GreenfootImage imagen = new GreenfootImage("Musica", 36, Color.BLACK, null);
        setImage(imagen);
    }
}
