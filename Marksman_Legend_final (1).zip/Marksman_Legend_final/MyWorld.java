import greenfoot.*; 

// Juego creado por Juan Esteban Rodriguez Sarmiento, Winston Andres Torres Monroy
public class MyWorld extends World
{
    Vida vida = new Vida ();
    Contador contador = new Contador ();
    public MyWorld()
    {    
        super(800, 500, 1); 
        Greenfoot.playSound("Menu2.mp3");        
        spawneo_0();
    }
    
    public Contador obtenerContador()
    {
        return contador;
    }
    
    public Vida obtenerVida()
    {
        return vida;
    }
    private void spawneo_0() {
        Victor victor = new Victor();
        addObject (victor,133,199);
        
        Zombie_1 zombie = new Zombie_1 ();
        addObject ( zombie ,398, 199);
        
        Zombie_1 zombie_2 = new Zombie_1 ();
        addObject ( zombie_2 ,484, 199);
        
        Zombie_1 zombie_3 = new Zombie_1 ();
        addObject ( zombie_3 ,555, 199);
        
        Zombie_1 zombie_4 = new Zombie_1 ();
        addObject ( zombie_4 ,626, 199);
        
        Zombie_1 zombie_5 = new Zombie_1 ();
        addObject ( zombie_5 ,697, 199);
        
        addObject (contador, 93, 25);
        
        addObject (vida, 753, 21);
        
        flecha_1 flecha = new flecha_1 ();
        addObject (flecha, 764, 189);
    }
}

