import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Mapa_3 extends World
{
    Vida vida = new Vida ();
    Contador contador = new Contador ();
    
    public Mapa_3()
    {    
        super(1100, 500, 1);
        spawneo_0();
    }
    public Contador obtenerContador()
    {
        return contador;
    }
    
    public Vida obtenerVida()
    {
        return vida;
    }
    private void spawneo_0() {
        Victor victor = new Victor();
        addObject (victor,210,444);
        
        Zombie_3 zombie_3 = new Zombie_3 ();
        addObject ( zombie_3 ,683, 434);
        
        Zombie_3 zombie_4 = new Zombie_3 ();
        addObject ( zombie_4 ,747, 461);
        
        Zombie_3 zombie_5 = new Zombie_3 ();
        addObject ( zombie_5 ,798, 424);
        
        Zombie_3 zombie_6 = new Zombie_3 ();
        addObject ( zombie_6 ,844, 449);
        
        Zombie_3 zombie_7 = new Zombie_3 ();
        addObject ( zombie_7 ,914, 444);
        
        addObject (vida, 893, 35);
        
        addObject (contador, 95, 25);
        
        flecha_3 flecha = new flecha_3 ();
        addObject (flecha, 1051, 402);
    }
    
}
