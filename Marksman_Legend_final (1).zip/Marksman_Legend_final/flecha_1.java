import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class flecha_1 extends Actor
{
   
    public void act()
    {
        // Add your action code here.
    }
}
