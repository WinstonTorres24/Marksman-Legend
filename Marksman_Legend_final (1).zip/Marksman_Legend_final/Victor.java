import greenfoot.*;  

public class Victor extends Actor
{
    int velocidad_X;
    int velocidad_Y;
    int Y_ref;
    boolean poderDisparar = true;
    GreenfootImage img_derecha;
    GreenfootImage img_izquierda;
    GreenfootImage img_disparar_;
    GreenfootImage img_disparar_mov;
    private GreenfootSound sounds = new GreenfootSound("Menu2.mp3");
    public void act()
    {
        movimiento();
        disparar ();
        gravedad();
        nivel_2();
        nivel_3();
        nivel_4();
        nivel_5();
        hacer_daño();
        fin();
    }
    
    public void movimiento(){
     velocidad_X=3;
     velocidad_Y=1;
     Y_ref=199;
     img_derecha = new GreenfootImage ("victor_derecha_.png");
     img_izquierda = new GreenfootImage ("victor_default_.png");
     img_disparar_ = new GreenfootImage ("victor_shoot_.png");
     img_disparar_mov = new GreenfootImage ("victor_run_shoot_.png");
     if (Greenfoot.isKeyDown("right")){
        setImage(img_derecha);
        setLocation (getX() + velocidad_X, getY());
        }
     
     if (Greenfoot.isKeyDown("left")){
        setImage (img_izquierda);
        setLocation (getX() - velocidad_X, getY());
        
        }
     
     if (Greenfoot.isKeyDown("up")){
        setLocation (getX(), getY() -7);
        }    
    }
    
    public void gravedad (){
        if (getY()<Y_ref) {
            setLocation(getX(), getY() +velocidad_Y);
        }
    }
        
    public void disparar (){
        if (Greenfoot.isKeyDown("space")  && poderDisparar == true) 
        {
            setImage (img_disparar_);
            getWorld().addObject(new bala(), getX()+27, getY()-10);
            poderDisparar = false;
        }
        else if (!Greenfoot.isKeyDown("space")){
            poderDisparar = true;
        }
        
        if (Greenfoot.isKeyDown ("space") && Greenfoot.isKeyDown ("right")){
            setImage (img_disparar_mov);
        }
    }
    
    
    public void nivel_2()
    {
        Actor flecha_1 = getOneIntersectingObject(flecha_1.class);
        if (flecha_1 != null)
        {
            Greenfoot.setWorld(new Mapa_2());
            sounds.playLoop();
        }
    }
    
    public void nivel_3()
    {
        Actor flecha_2 = getOneIntersectingObject(flecha_2.class);
        if (flecha_2 != null)
        {
            Greenfoot.setWorld(new Mapa_3());
        }
    }
    
     public void nivel_4()
    {
        Actor flecha_3 = getOneIntersectingObject(flecha_3.class);
        if (flecha_3 != null)
        {
            Greenfoot.setWorld(new Mapa_4());
        }
    }
    
      public void nivel_5()
    {
        Actor flecha_4 = getOneIntersectingObject(flecha_4.class);
        if (flecha_4 != null)
        {
            Greenfoot.setWorld(new Mapa_5());
        }
    }
    
    public void hacer_daño()
    {
        Actor Zombie_1 = getOneIntersectingObject(Zombie_1.class);
        Actor Zombie_2 = getOneIntersectingObject(Zombie_2.class);
        Actor Zombie_3 = getOneIntersectingObject(Zombie_3.class);
        Actor Zombie_4 = getOneIntersectingObject(Zombie_4.class);
        Actor Zombie_5 = getOneIntersectingObject(Zombie_5.class);
        if (Zombie_1 != null)
        {
            World world = getWorld();
            MyWorld myWorld = (MyWorld)world;
            Vida vida = myWorld.obtenerVida();
            vida.perder_vida();
        }
        
        if(Zombie_2 != null)
        {
            World world = getWorld();
            Mapa_2 mapa_2 = (Mapa_2)world;
            Vida vida = mapa_2.obtenerVida();
            vida.perder_vida();
        }
        
        if(Zombie_3 != null)
        {
            World world = getWorld();
            Mapa_3 mapa_3 = (Mapa_3)world;
            Vida vida = mapa_3.obtenerVida();
            vida.perder_vida();
        }
        
        if(Zombie_4 != null)
        {
            World world = getWorld();
            Mapa_4 mapa_4 = (Mapa_4)world;
            Vida vida = mapa_4.obtenerVida();
            vida.perder_vida();
        }
        
        if(Zombie_5 != null)
        {
            World world = getWorld();
            Mapa_5 mapa_5 = (Mapa_5)world;
            Vida vida = mapa_5.obtenerVida();
            vida.perder_vida();
        }
    }
    
    public void fin()
    {
      Actor Cura = getOneIntersectingObject(Cura.class); 
      if (Cura != null)
        {
            getWorld().addObject(new Fin(), 496, 239);
            Greenfoot.stop();
        }
    }
}
