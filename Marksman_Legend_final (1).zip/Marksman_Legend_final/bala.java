import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class bala extends Actor
{
    boolean disparo = true;
    public void act()
    {
        desplazamiento();
    }
    
    public void desplazamiento (){
        setLocation (getX()+10 , getY() );
        
    }
    
}

