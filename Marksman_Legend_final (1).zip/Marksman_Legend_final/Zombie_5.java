import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Zombie_5 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Zombie_5 extends Zombies
{
     int contador_balas= 24;
    int contador_enemigos1= 5;
    public void act()
    {
        eliminar_enemigo ();
    }
    
    public void eliminar_enemigo (){
        Actor bala = getOneIntersectingObject(bala.class);
        if (bala != null){
            getWorld().removeObject(bala);
            contador_balas --;
        }
        if (contador_balas==0)
        {          
            contador_enemigos1 = contador_enemigos1 - 1;
            World world = getWorld();
            Mapa_5 mapa_5 = (Mapa_5)world;
            Contador contador = mapa_5.obtenerContador();
            contador.sumarPuntaje();
            getWorld().removeObject(this);
        }
    }
}
