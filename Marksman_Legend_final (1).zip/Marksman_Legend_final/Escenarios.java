 import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.ArrayList;

/**
 * Write a description of class Escenarios here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Escenarios extends World
{
    public Escenarios()
    {
        super(800, 600, 1);
        // Agrega botones o imágenes para los mapas y asigna eventos a estos elementos
        // Ejemplo de un botón para el mapa 1
        BotonMapa botonMyWorld = new BotonMapa("Mapa 1");
        addObject(botonMyWorld, 200, 150);
        BotonMapa botonMapa2 = new BotonMapa("Mapa 2");
        addObject(botonMapa2, 600, 150);
        BotonMapa botonMapa3 = new BotonMapa("Mapa 3");
        addObject(botonMapa3, 200, 350);
        BotonMapa botonMapa4 = new BotonMapa("Mapa 4");
        addObject(botonMapa4, 600, 350);
        BotonMapa botonMapa5 = new BotonMapa("Mapa 5");
        addObject(botonMapa5, 400, 550);
    }
}
