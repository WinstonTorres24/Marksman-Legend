import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Zombie_2 extends Zombies
{
    int contador_balas= 3;
    int contador_enemigos1= 5;
    public void act()
    {
        avanzar_2();
        eliminar_enemigo ();
    }
    
    public void eliminar_enemigo (){
        Actor bala = getOneIntersectingObject(bala.class);
        if (bala != null){
            getWorld().removeObject(bala);
            contador_balas --;
        }
        if (contador_balas==0)
        {          
            contador_enemigos1 = contador_enemigos1 - 1;
            World world = getWorld();
            Mapa_2 mapa_2 = (Mapa_2)world;
            Contador contador = mapa_2.obtenerContador();
            contador.sumarPuntaje();
            getWorld().removeObject(this);
        }
    }
    public void avanzar_2(){
        setLocation(getX()-1 ,getY());
    }
}
