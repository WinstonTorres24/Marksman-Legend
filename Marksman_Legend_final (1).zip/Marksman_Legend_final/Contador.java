import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Contador extends Actor
{
    int puntaje = 0;
    public Contador ()
    {
       setImage (new GreenfootImage("Puntaje: "+puntaje  , 50, Color.ORANGE, Color.BLACK)); 
    }
    public void act()
    {
        setImage (new GreenfootImage("Puntaje: "+puntaje , 50, Color.ORANGE, Color.BLACK));
    }
    public void sumarPuntaje ()
    {
        puntaje++;
    }
}
