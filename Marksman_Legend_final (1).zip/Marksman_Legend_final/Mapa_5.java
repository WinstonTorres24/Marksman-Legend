import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Mapa_5 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Mapa_5 extends World
{
   Vida vida = new Vida ();
    Contador contador = new Contador ();
    
    public Mapa_5()
    {    
        super(960, 500, 1);
        spawneo_0();
    }
    public Contador obtenerContador()
    {
        return contador;
    }
    
    public Vida obtenerVida()
    {
        return vida;
    }
    private void spawneo_0() {
        Victor victor = new Victor();
        addObject (victor,172,440);
        
        Zombie_5 zombie_1 = new Zombie_5 ();
        addObject ( zombie_1 ,692, 303);
        
        addObject (vida, 893, 35);
        
        addObject (contador, 95, 25);
        
        Cura llave = new Cura ();
        addObject (llave, 914, 416);
    
    }
    
}
