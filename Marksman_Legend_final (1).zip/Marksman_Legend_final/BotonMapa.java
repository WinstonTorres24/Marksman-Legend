import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class BotonMapa extends Actor
{
    private String nombreMapa;
    public BotonMapa(String nombreMapa) {
        this.nombreMapa = nombreMapa;
        actualizarImagen();
    }
    private void actualizarImagen()
    {
        GreenfootImage imagen = new GreenfootImage(nombreMapa, 40, Color.BLACK, null);
        setImage(imagen);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            // Cuando se hace clic en el botón, crea la instancia del escenario correspondiente
            if (nombreMapa.equals("Mapa 1")) {
                Greenfoot.setWorld(new MyWorld()); // Crea una instancia de Mapa1 o la clase que hayas creado para el mapa 1
            } else if (nombreMapa.equals("Mapa 2")) {
                Greenfoot.setWorld(new Mapa_2()); // Crea una instancia de Mapa2 o la clase que hayas creado para el mapa 2
            }else if (nombreMapa.equals("Mapa 3")) {
                Greenfoot.setWorld(new Mapa_3()); // Crea una instancia de Mapa2 o la clase que hayas creado para el mapa 2
            }else if (nombreMapa.equals("Mapa 4")) {
                Greenfoot.setWorld(new Mapa_4()); // Crea una instancia de Mapa2 o la clase que hayas creado para el mapa 2
            }else if (nombreMapa.equals("Mapa 5")) {
                Greenfoot.setWorld(new Mapa_5()); // Crea una instancia de Mapa2 o la clase que hayas creado para el mapa 2
            }
            // Agrega más condiciones para otros mapas si es necesario
        }
    }
}
