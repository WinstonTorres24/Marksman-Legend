import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Zombies extends Actor
{

    public void act()
    {
        // Add your action code here.
    }
    
    public void avanzar()
    {
        setLocation(getX()-1 ,getY());
    }
}
