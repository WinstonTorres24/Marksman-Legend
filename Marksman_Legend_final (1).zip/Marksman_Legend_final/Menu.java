import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menu extends World
{
    private GreenfootSound sound = new GreenfootSound("Menu.mp3");
    Flecha flecha = new Flecha();
    private int option = 0;
    private String nombrePlayer;
    /**
     * Constructor for objects of class Menu.
     * 
     */
    public Menu()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 500, 1); 
        solicitarNombrePlayer();
        addObject(new NombreJuego(), 400, 100);
        CreacionMenu();
        play();
    }
    
    public void play(){
        sound.play();
    }
    private void solicitarNombrePlayer(){
        nombrePlayer = Greenfoot.ask("Por favor, ingresar el nombre del jugador: ");
        
        if (nombrePlayer != null && !nombrePlayer.isEmpty()){
        CreacionMenu();
        }
        else{
            solicitarNombrePlayer();
        }
        
    }
    
    private void CreacionMenu(){
        addObject(new Inicio(),400,150);
        addObject(new Mapa(),400,200);
        addObject(new Salir(),400,400);
        addObject(flecha, 275,150);
    }
    
    public void act(){
        if (Greenfoot.isKeyDown("UP") && option >0) {option--;}
        if (Greenfoot.isKeyDown("DOWN") && option <5) {option++;}
        
        if(option>=6) option=0;
        if(option<0) option=5;
        
        
        if (Greenfoot.isKeyDown("SPACE") || Greenfoot.isKeyDown("ENTER")){
            switch(option){
                case 0: //Inicio
                sound.stop();
                Greenfoot.setWorld(new MyWorld());
                break;
                case 1: //Mapa
                sound.stop();
                Greenfoot.setWorld(new Escenarios());
                break;
                case 2: //Musica
                sound.stop();
                Greenfoot.setWorld(new Sonido());
                break;
                case 3:
                sound.stop();
                Greenfoot.setWorld(new Score());
                
                break;
                case 4:
                    sound.stop();
                break;
                case 5: //Salir
                sound.stop();
                Greenfoot.stop();
                break;
            }
        }
        flecha.setLocation(275,150 +(option*50));
    }
}
