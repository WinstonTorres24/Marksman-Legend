import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Vida extends Actor
{
    int vida = 60;
    int barra_vida_hori = 120;
    int barra_vida_verti = 10;
    int puntos_vida = barra_vida_hori/vida;
    public void barravida()
    {
        actualizar ();
    }
    public void act()
    {
        actualizar ();
        mision_fallida();
    }
    
    public void actualizar ()
    {
        setImage (new GreenfootImage (barra_vida_hori, barra_vida_verti));
        GreenfootImage imagen = getImage();
        imagen.setColor (Color.WHITE);
        imagen.drawRect (0, 0, barra_vida_hori + 1, barra_vida_verti  + 1);
        imagen.setColor(Color.RED);
        imagen.fillRect(1,1, vida*puntos_vida, barra_vida_verti);
    }
    
    public void perder_vida() 
    {
        vida--;
    }
    
    public void mision_fallida()
    {
        if (vida == 0)
        {
            getWorld().addObject(new Mision_fallida(), 419, 236);
            Greenfoot.stop();
        }
    }
}
