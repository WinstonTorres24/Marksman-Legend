import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Mapa_4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Mapa_4 extends World
{
    Vida vida = new Vida ();
    Contador contador = new Contador ();
    
    public Mapa_4()
    {    
        super(1100, 600, 1);
        spawneo_0();
    }
    public Contador obtenerContador()
    {
        return contador;
    }
    
    public Vida obtenerVida()
    {
        return vida;
    }
    private void spawneo_0() {
        Victor victor = new Victor();
        addObject (victor,172,537);
        
        Zombie_4 zombie_1 = new Zombie_4 ();
        addObject ( zombie_1 ,807, 538);
        
        Zombie_4 zombie_2 = new Zombie_4 ();
        addObject ( zombie_2 ,852, 529);
        
        Zombie_4 zombie_3 = new Zombie_4 ();
        addObject ( zombie_3 ,893, 553);
        
        Zombie_4 zombie_4 = new Zombie_4 ();
        addObject ( zombie_4 ,927, 535);
        
        Zombie_4 zombie_5 = new Zombie_4 ();
        addObject ( zombie_5 ,996, 532);
        
        addObject (vida, 893, 35);
        
        addObject (contador, 95, 25);
        
        flecha_4 flecha = new flecha_4 ();
        addObject (flecha, 1054, 528);
    }
    
}
