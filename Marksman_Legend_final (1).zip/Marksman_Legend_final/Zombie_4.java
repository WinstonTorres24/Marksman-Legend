import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Zombie_4 extends Zombies
{
    int contador_balas= 8;
    int contador_enemigos1= 5;
    public void act()
    {
        avanzar_3();
        eliminar_enemigo ();
    }
    
    public void eliminar_enemigo (){
        Actor bala = getOneIntersectingObject(bala.class);
        if (bala != null){
            getWorld().removeObject(bala);
            contador_balas --;
        }
        if (contador_balas==0)
        {          
            contador_enemigos1 = contador_enemigos1 - 1;
            World world = getWorld();
            Mapa_4 mapa_4 = (Mapa_4)world;
            Contador contador = mapa_4.obtenerContador();
            contador.sumarPuntaje();
            getWorld().removeObject(this);
        }
    }
    public void avanzar_3(){
        setLocation(getX()-2 ,getY());
    }
}
