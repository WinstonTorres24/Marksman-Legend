import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Mapa_2 extends World
{
    Vida vida = new Vida ();
    Contador contador = new Contador ();
    
    public Mapa_2()
    {    
        super(1000, 500, 1);
        spawneo_0();
    }
    public Contador obtenerContador()
    {
        return contador;
    }
    
    public Vida obtenerVida()
    {
        return vida;
    }
    private void spawneo_0() {
        Victor victor = new Victor();
        addObject (victor,39,417);
        
        Zombie_2 zombie = new Zombie_2 ();
        addObject ( zombie ,569, 418);
        
        Zombie_2 zombie_2 = new Zombie_2 ();
        addObject ( zombie_2 ,638, 422);
        
        Zombie_2 zombie_3 = new Zombie_2 ();
        addObject ( zombie_3 ,709, 412);
        
        Zombie_2 zombie_4 = new Zombie_2 ();
        addObject ( zombie_4 ,766, 422);
        
        Zombie_2 zombie_5 = new Zombie_2 ();
        addObject ( zombie_5 ,838, 408);
        
        Zombie_2 zombie_6 = new Zombie_2 ();
        addObject ( zombie_6 ,878, 425);
        
        addObject (vida, 893, 35);
        
        addObject (contador, 95, 25);
        
        flecha_2 flecha = new flecha_2 ();
        addObject (flecha, 958, 412);
    }
    
}

